<?php
include 'koneksi.php';

$id_tanah = $_POST['id_tanah'];
$nama_pemilik = $_POST['nama_pemilik'];
$lokasi = $_POST['lokasi'];
$kota = $_POST['kota'];
$panjang = $_POST['panjang'];
$lebar = $_POST['lebar'];

$hasil = $db->query("update tanah set
                     nama_pemilik = '$nama_pemilik', 
                     lokasi = '$lokasi', 
                     kota = '$kota', 
                     panjang = '$panjang', 
                     lebar = '$lebar'
                     where tanah.id_tanah = '$id_tanah'");

header('location:daftar_tanah.php');
