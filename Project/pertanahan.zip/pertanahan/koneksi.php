<?php
$h = 'localhost';
$u = 'root';
$p = '';
$d = 'pertanahan';

$db = mysqli_connect($h, $u, $p, $d);
