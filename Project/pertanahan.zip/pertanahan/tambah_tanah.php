<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, 
        shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <title>Data Tanah Baru</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Data Tanah Baru</h1>
        <a href="index.php" class="btn btn-primary">Beranda</a>
        <hr>
        <div class="row">
          <div class="col-md-6">
            <form action="simpan_tanah.php" method="POST">
              <div class="form-group">
                <label for="">Nama Pemilik</label>
                <input type="text" name="nama_pemilik" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Lokasi</label>
                <input type="text" name="lokasi" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Kota</label>
                <select name="kota" class="form-control">
                  <option value="Banjarmasin">Banjarmasin</option>
                  <option value="Banjarbaru">Banjarbaru</option>
                  <option value="Martapura">Martapura</option>
                </select>
              </div>
              <div class="form-group">
                <label for="">Panjang</label>
                <input type="number" name="panjang" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Lebar</label>
                <input type="number" name="lebar" class="form-control">
              </div>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
          </div>
        </div>
        <br>
        <p>Dibuat Oleh : [Nama Peserta]</p>
      </div>
    </div>

  </div>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>