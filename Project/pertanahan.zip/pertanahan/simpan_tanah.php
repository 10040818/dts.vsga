<?php
include 'koneksi.php';

$nama_pemilik = $_POST['nama_pemilik'];
$lokasi = $_POST['lokasi'];
$kota = $_POST['kota'];
$panjang = $_POST['panjang'];
$lebar = $_POST['lebar'];

$hasil = $db->query("insert into tanah (nama_pemilik, lokasi, kota, panjang, lebar)
                    values ('$nama_pemilik', '$lokasi', '$kota', '$panjang', '$lebar')");

header('location:daftar_tanah.php');
