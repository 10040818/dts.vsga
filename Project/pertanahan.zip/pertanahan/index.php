<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, 
        shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <title>Hello, world!</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <br>
        <div class="jumbotron">
          <h1>Sistem Informasi Pertanahan</h1>
          <a href="daftar_tanah.php" class="btn btn-primary btn-lg" role="button">Daftar Tanah</a>
          <a href="tambah_tanah.php" class="btn btn-warning btn-lg" role="button">Data Tanah Baru</a>
          <br>
          <br>
          <p>Dibuat oleh : [Nama Peserta]</p>
        </div>
      </div>
    </div>
  </div>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>