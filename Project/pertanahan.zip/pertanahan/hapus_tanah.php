<?php
include 'koneksi.php';

$id_tanah = $_GET['id_tanah'];

$hasil = $db->query("delete from tanah 
                     where tanah.id_tanah = '$id_tanah'");

header('location:daftar_tanah.php');
