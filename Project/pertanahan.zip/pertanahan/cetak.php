<?php
include 'koneksi.php';

$tanah = $db->query("select tanah.* from tanah");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, 
        shrink-to-fit=no">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Daftar Tanah</title>
</head>

<body onload="window.print();">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Daftar Tanah</h1>
                <hr>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">ID Tanah</th>
                            <th>Nama Pemilik</th>
                            <th>Lokasi</th>
                            <th>Kota</th>
                            <th class="text-right">Panjang</th>
                            <th class="text-right">Lebar</th>
                            <th class="text-right">Luas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tanah as $row) { ?>
                            <tr>
                                <td class="text-center"><?php echo $row['id_tanah'] ?></td>
                                <td><?php echo $row['nama_pemilik'] ?></td>
                                <td><?php echo $row['lokasi'] ?></td>
                                <td><?php echo $row['kota'] ?></td>
                                <td class="text-right"><?php echo $row['panjang'] ?></td>
                                <td class="text-right"><?php echo $row['lebar'] ?></td>
                                <td class="text-right"><?php echo $row['panjang'] * $row['lebar'] ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <p>Dibuat Oleh : [Nama Peserta]</p>
            </div>
        </div>

    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>