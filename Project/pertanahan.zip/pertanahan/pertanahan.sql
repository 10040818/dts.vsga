-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for pertanahan
DROP DATABASE IF EXISTS `pertanahan`;
CREATE DATABASE IF NOT EXISTS `pertanahan` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pertanahan`;

-- Dumping structure for table pertanahan.tanah
DROP TABLE IF EXISTS `tanah`;
CREATE TABLE IF NOT EXISTS `tanah` (
  `id_tanah` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pemilik` varchar(50) DEFAULT NULL,
  `lokasi` varchar(50) DEFAULT NULL,
  `kota` varchar(50) DEFAULT NULL,
  `panjang` int(11) DEFAULT NULL,
  `lebar` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tanah`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table pertanahan.tanah: ~4 rows (approximately)
/*!40000 ALTER TABLE `tanah` DISABLE KEYS */;
REPLACE INTO `tanah` (`id_tanah`, `nama_pemilik`, `lokasi`, `kota`, `panjang`, `lebar`) VALUES
	(1, 'Kayla', 'Mulawarman', 'Banjarmasin', 20, 10),
	(2, 'Dede Saputra', 'A. Yani', 'Banjarbaru', 15, 9),
	(3, 'Putri', 'Pembangunan', 'Martapura', 20, 20),
	(4, 'Ulfah', 'Manarap', 'Martapura', 30, 12);
/*!40000 ALTER TABLE `tanah` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
