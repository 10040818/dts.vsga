<?php
include 'koneksi.php';
$id_tanah = $_GET['id_tanah'];

$hasil = $db->query("select tanah.* from tanah 
                     where tanah.id_tanah = '$id_tanah'");
$tanah = mysqli_fetch_assoc($hasil);

?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, 
        shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <title>Edit Data Tanah</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Edit Data Tanah</h1>
        <a href="index.php" class="btn btn-primary">Beranda</a>
        <hr>
        <div class="row">
          <div class="col-md-6">
            <form action="update_tanah.php" method="POST">
              <input type="hidden" name="id_tanah" value="<?php echo $tanah['id_tanah'] ?>">
              <div class="form-group">
                <label for="">Nama Pemilik</label>
                <input type="text" name="nama_pemilik" class="form-control" value="<?php echo $tanah['nama_pemilik'] ?>">
              </div>
              <div class="form-group">
                <label for="">Lokasi</label>
                <input type="text" name="lokasi" class="form-control" value="<?php echo $tanah['lokasi'] ?>">
              </div>
              <div class="form-group">
                <label for="">Kota</label>
                <select name="kota" class="form-control">
                  <option value="Banjarmasin" <?php echo $tanah['kota'] == 'Banjarmasin' ? 'selected' : '' ?>>Banjarmasin</option>
                  <option value="Banjarbaru" <?php echo $tanah['kota'] == 'Banjarbaru' ? 'selected' : '' ?>>Banjarbaru</option>
                  <option value="Martapura" <?php echo $tanah['kota'] == 'Martapura' ? 'selected' : '' ?>>Martapura</option>
                </select>
              </div>
              <div class="form-group">
                <label for="">Panjang</label>
                <input type="number" name="panjang" class="form-control" value="<?php echo $tanah['panjang'] ?>">
              </div>
              <div class="form-group">
                <label for="">Lebar</label>
                <input type="number" name="lebar" class="form-control" value="<?php echo $tanah['lebar'] ?>">
              </div>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
          </div>
        </div>
        <br>
        <p>Dibuat Oleh : [Nama Peserta]</p>
      </div>
    </div>

  </div>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>