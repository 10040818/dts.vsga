<?php
$h = 'localhost';
$u = 'root';
$p = '';
$d = 'db_dts_2020';

$db = mysqli_connect($h, $u, $p, $d);
