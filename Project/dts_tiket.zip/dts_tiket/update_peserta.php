<?php
include 'koneksi.php';

$id_pemesanan = $_POST['id_pemesanan'];
$nama_pemesan = $_POST['nama_pemesan'];
$tgl_pemesanan = $_POST['tgl_pemesanan'];
$judul_film = $_POST['judul_film'];
$harga = $_POST['harga'];
$jml_penonton = $_POST['jml_penonton'];

$db->query("update pemesanan 
            set pemesanan.nama_pemesan = '$nama_pemesan', 
            pemesanan.tgl_pemesanan = '$tgl_pemesanan', 
            pemesanan.judul_film = '$judul_film', 
            pemesanan.harga = '$harga', 
            pemesanan.jml_penonton = '$jml_penonton'
            where pemesanan.id_pemesanan = '$id_pemesanan'  
            ");

header('location:pemesanan.php');
