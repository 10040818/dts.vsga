<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- link untuk loading bootstrap.css -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <title>Daftar Pemesanan Tiket</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Daftar Pemesanan Tiket</h1>
        <a href="cetak_pemesanan.php" class="btn btn-success">Cetak</a>
        <a href="cetak_pemesanan_xls.php" class="btn btn-success">Cetak Xls</a>
        <table class="table table-hover table-striped">
          <thead>
            <tr>
              <th>No.</th>
              <th>Nama Pemesanan</th>
              <th>Tanggal</th>
              <th>Judul Film</th>
              <th>Harga Tiket</th>
              <th>Jumlah Penonton</th>
              <th>Subtotal</th>
              <th>Diskon</th>
              <th>Total</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include 'koneksi.php';
            $pemesanan = $db->query("select pemesanan.* from pemesanan");
            $no = 1;
            ?>

            <?php foreach ($pemesanan as $row) { ?>
              <tr>
                <?php
                  $subtotal = $row['harga'] * $row['jml_penonton'];

                  if ($row['jml_penonton'] <= 5) {
                    $diskon = 0;
                  } else if ($row['jml_penonton'] <= 10) {
                    $diskon = $subtotal * 10 / 100;
                  } else {
                    $diskon = $subtotal * 20 / 100;
                  }

                  $total = $subtotal - $diskon;
                  ?>
                <td><?php echo $no++ ?></td>
                <td><?php echo $row['nama_pemesan'] ?></td>
                <td><?php echo $row['tgl_pemesanan'] ?></td>
                <td><?php echo $row['judul_film'] ?></td>
                <td><?php echo $row['harga'] ?></td>
                <td><?php echo $row['jml_penonton'] ?></td>
                <td><?php echo $subtotal ?></td>
                <td><?php echo $diskon ?></td>
                <td><?php echo $total ?></td>
                <td>
                  <a href="edit_pemesanan.php?id=<?php echo $row['id_pemesanan'] ?>" class="btn btn-xs btn-warning">Edit</a>
                  <a href="hapus_pemesanan.php?id=<?php echo $row['id_pemesanan'] ?>" class="btn btn-xs btn-danger">Hapus</a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- script untuk loading jquery.min.js  -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>