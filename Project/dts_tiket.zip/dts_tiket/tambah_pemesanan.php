<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Daftar Pemesanan Tiket</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="well" style="margin-top: 50px;">
                    <h1>Data Pemesanan Tiket</h1>
                    <form action="insert_pemesanan.php" method="post">
                        <div class="form-group">
                            <label for="">Nama Pemesan</label>
                            <input type="text" name="nama_pemesan" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal Pemesanan</label>
                            <input type="date" name="tgl_pemesanan" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Judul Film</label>
                            <?php $film = ['Jurassic Park', 'Smurf', 'Mission Impossible']; ?>
                            <select name="judul_film" id="" class="form-control">
                                <?php foreach ($film as $val) { ?>
                                    <option value="<?php echo $val ?>"><?php echo $val ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Harga</label>
                            <input type="number" name="harga" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Jumlah Penonton</label>
                            <input type="number" name="jml_penonton" class="form-control">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>