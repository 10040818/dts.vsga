<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Bioskop XXI - Tiket Online</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="well" style="margin-top: 50px; padding: 30px;">
                    <h1>Bioskop XXI - Tiket Online</h1>
                    <hr>
                    <a href="pemesanan.php" class="btn btn-primary btn-lg">Daftar Pemesanan</a>
                    <a href="tambah_pemesanan.php" class="btn btn-warning btn-lg">Pemesanan Baru</a>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>