<?php
$h = 'localhost';
$u = 'root';
$p = '';
$d = 'db_dts';

$db = mysqli_connect($h, $u, $p, $d);
