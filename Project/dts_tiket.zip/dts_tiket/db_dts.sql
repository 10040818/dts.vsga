-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for db_dts
DROP DATABASE IF EXISTS `db_dts`;
CREATE DATABASE IF NOT EXISTS `db_dts` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_dts`;

-- Dumping structure for table db_dts.kota
DROP TABLE IF EXISTS `kota`;
CREATE TABLE IF NOT EXISTS `kota` (
  `id_kota` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kota` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_kota`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.kota: ~3 rows (approximately)
/*!40000 ALTER TABLE `kota` DISABLE KEYS */;
REPLACE INTO `kota` (`id_kota`, `nama_kota`) VALUES
	(3, 'Martapura'),
	(4, 'Banjarmasin');
/*!40000 ALTER TABLE `kota` ENABLE KEYS */;

-- Dumping structure for table db_dts.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id_orders` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelanggan` varchar(50) DEFAULT NULL,
  `tgl_order` date DEFAULT NULL,
  `member` enum('Y','T') DEFAULT NULL,
  `tgl_selesai` date DEFAULT NULL,
  `jml_kg` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_orders`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.orders: ~2 rows (approximately)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
REPLACE INTO `orders` (`id_orders`, `nama_pelanggan`, `tgl_order`, `member`, `tgl_selesai`, `jml_kg`) VALUES
	(1, 'RONNY', '2019-10-27', 'Y', '2019-10-27', 6),
	(2, 'NAURA', '2019-10-27', 'T', '2019-10-27', 20);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Dumping structure for table db_dts.pekerjaan
DROP TABLE IF EXISTS `pekerjaan`;
CREATE TABLE IF NOT EXISTS `pekerjaan` (
  `id_pekerjaan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pekerjaan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_pekerjaan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.pekerjaan: ~4 rows (approximately)
/*!40000 ALTER TABLE `pekerjaan` DISABLE KEYS */;
REPLACE INTO `pekerjaan` (`id_pekerjaan`, `nama_pekerjaan`) VALUES
	(1, 'TNI'),
	(2, 'Polri'),
	(3, 'PNS'),
	(4, 'Wiraswata');
/*!40000 ALTER TABLE `pekerjaan` ENABLE KEYS */;

-- Dumping structure for table db_dts.pelatihan
DROP TABLE IF EXISTS `pelatihan`;
CREATE TABLE IF NOT EXISTS `pelatihan` (
  `id_pelatihan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelatihan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_pelatihan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.pelatihan: ~2 rows (approximately)
/*!40000 ALTER TABLE `pelatihan` DISABLE KEYS */;
REPLACE INTO `pelatihan` (`id_pelatihan`, `nama_pelatihan`) VALUES
	(1, 'Junior Web Developer'),
	(2, 'Junior Mobile Developer');
/*!40000 ALTER TABLE `pelatihan` ENABLE KEYS */;

-- Dumping structure for table db_dts.pemesanan
DROP TABLE IF EXISTS `pemesanan`;
CREATE TABLE IF NOT EXISTS `pemesanan` (
  `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pemesan` varchar(50) DEFAULT NULL,
  `tgl_pemesanan` date DEFAULT NULL,
  `judul_film` varchar(50) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `jml_penonton` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pemesanan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.pemesanan: ~2 rows (approximately)
/*!40000 ALTER TABLE `pemesanan` DISABLE KEYS */;
REPLACE INTO `pemesanan` (`id_pemesanan`, `nama_pemesan`, `tgl_pemesanan`, `judul_film`, `harga`, `jml_penonton`) VALUES
	(1, 'Ronny Faslah', '2019-10-26', 'Jurassic Park', 50000, 6),
	(2, 'Test', '2019-10-19', 'Smurf', 60000, 5);
/*!40000 ALTER TABLE `pemesanan` ENABLE KEYS */;

-- Dumping structure for table db_dts.peserta
DROP TABLE IF EXISTS `peserta`;
CREATE TABLE IF NOT EXISTS `peserta` (
  `id_peserta` int(11) NOT NULL AUTO_INCREMENT,
  `nama_peserta` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jk` enum('L','P') DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `id_kota` int(11) DEFAULT NULL,
  `id_pekerjaan` int(11) DEFAULT NULL,
  `id_pelatihan` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_peserta`),
  KEY `FK_peserta_kota` (`id_kota`),
  KEY `FK_peserta_pekerjaan` (`id_pekerjaan`),
  CONSTRAINT `FK_peserta_kota` FOREIGN KEY (`id_kota`) REFERENCES `kota` (`id_kota`) ON UPDATE CASCADE,
  CONSTRAINT `FK_peserta_pekerjaan` FOREIGN KEY (`id_pekerjaan`) REFERENCES `pekerjaan` (`id_pekerjaan`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table db_dts.peserta: ~5 rows (approximately)
/*!40000 ALTER TABLE `peserta` DISABLE KEYS */;
REPLACE INTO `peserta` (`id_peserta`, `nama_peserta`, `tgl_lahir`, `jk`, `alamat`, `id_kota`, `id_pekerjaan`, `id_pelatihan`) VALUES
	(1, 'Ronny Faslah 1', '2019-10-06', 'L', 'Jl. Permata', 4, 3, 1),
	(2, 'Naura', '2019-10-06', 'P', 'Jl. Tanjung 3', 3, 4, 1),
	(3, 'Azka', '2019-10-06', 'L', 'Jl. Cemara', 4, 3, 1),
	(4, 'Ronny Faslah1', '2019-10-06', 'L', 'Jl. Permata', 4, 3, 1),
	(5, 'Ronny Faslah1', '2019-10-06', 'L', 'Jl. Permata', 4, 3, 1);
/*!40000 ALTER TABLE `peserta` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
