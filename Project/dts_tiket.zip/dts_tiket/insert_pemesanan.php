<?php
include 'koneksi.php';

$nama_pemesan = $_POST['nama_pemesan'];
$tgl_pemesanan = $_POST['tgl_pemesanan'];
$judul_film = $_POST['judul_film'];
$harga = $_POST['harga'];
$jml_penonton = $_POST['jml_penonton'];

$db->query("insert into pemesanan (nama_pemesan, tgl_pemesanan, 
            judul_film, harga, jml_penonton)  
            values('$nama_pemesan', '$tgl_pemesanan', 
            '$judul_film','$harga', '$jml_penonton')");

header('location:pemesanan.php');
