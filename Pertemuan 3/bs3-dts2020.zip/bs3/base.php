<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- link untuk loading bootstrap.css -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <title>Contoh Bootstrap</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Hello World</h1>
      </div>
    </div>
  </div>

  <!-- script untuk loading jquery.min.js  -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>