<?php
$server = 'localhost';
$user = 'root';
$password = '';
$nama_database = 'dts_2020';

$db = mysqli_connect($server, $user, $password, $nama_database);