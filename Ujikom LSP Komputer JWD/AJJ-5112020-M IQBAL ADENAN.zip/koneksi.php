<?php
$server = 'localhost';
$user = 'root';
$password = '';
$database = 'db-dts20';

$koneksi = mysqli_connect($server, $user, $password, $database);
