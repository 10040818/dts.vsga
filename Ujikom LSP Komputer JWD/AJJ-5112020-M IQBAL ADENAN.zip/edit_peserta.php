<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}

include 'koneksi.php';
$id = $_GET['id'];
$result = $koneksi->query("SELECT pendaftaran.* FROM pendaftaran WHERE pendaftaran.id = '$id'");
$peserta = mysqli_fetch_assoc($result);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Pendaftaran Siswa Baru</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <h1>Tambah Peserta Didik</h1>
                        <form action="update_peserta.php" method="POST">
                            <input type="hidden" name="id" value="<?= $peserta['id']; ?>">
                            <div class="form-group">
                                <label for="" class="control-label">Nama Lengkap</label>
                                <input type="text" class="form-control" name="nama_peserta" value="<?= $peserta['nama']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgl_lahir" value="<?= $peserta['tgl_lahir']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Alamat</label>
                                <textarea name="alamat" id="" cols="30" rows="10" class="form-control"><?= $peserta['alamat']; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Nama Lengkap</label>
                                <select name="agama" id="" class="form-control">
                                    <option selected disabled>Pilih Agama</option>
                                    <?php $all_agama = array('Islam', 'Khatolik', 'Protestan', 'Hindu', 'Budha', 'Konghuchu'); ?>
                                    <?php foreach ($all_agama as $agama) : ?>
                                        <option value="<?= $agama; ?>" <?= $agama == $peserta['agama'] ? 'selected' : '' ?>><?= $agama; ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Nama Lengkap</label>
                                <select name="kelas" id="" class="form-control">
                                    <option selected disabled>Pilih Kelas</option>
                                    <?php $all_kelas = array('X', 'XI', 'XII'); ?>
                                    <?php foreach ($all_kelas as $kelas) : ?>
                                        <option value="<?= $kelas; ?>" <?= $kelas == $peserta['kelas'] ? 'selected' : '' ?>><?= $kelas; ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Telepon</label>
                                <input type="number" class="form-control" name="telepon" value="<?= $peserta['telepon']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Nama Ibu</label>
                                <input type="text" class="form-control" name="nama_ibu" value="<?= $peserta['nama_ibu']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Nama Bapak</label>
                                <input type="text" class="form-control" name="nama_bapak" value="<?= $peserta['nama_bapak']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Telepon Orangtua</label>
                                <input type="number" class="form-control" name="telepon_ortu" value="<?= $peserta['telepon_ortu']; ?>" required>
                            </div>
                            <div class="from-group">
                                <button class="btn btn-warning">Update</button>
                                <a href="peserta.php" class="btn btn-default">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>