<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Pendaftaran Siswa Baru</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card-header">
                            <h2>Tambah Peserta Didik</h2>
                        </div>
                        <hr>
                        <div class="card-body">
                            <form action="insert_peserta.php" method="POST">
                                <div class="form-group">
                                    <label for="" class="control-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" name="nama_peserta" placeholder="Masukkan nama lengkap anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Tanggal Lahir</label>
                                    <input type="date" class="form-control" name="tgl_lahir" placeholder="Masukkan tanggal lahir anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Alamat</label>
                                    <textarea name="alamat" id="" cols="30" rows="10" class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Nama Lengkap</label>
                                    <select name="agama" id="" class="form-control">
                                        <option selected disabled>Pilih Agama</option>
                                        <?php $all_agama = array('Islam', 'Khatolik', 'Protestan', 'Hindu', 'Budha', 'Konghuchu'); ?>
                                        <?php foreach ($all_agama as $agama) : ?>
                                            <option value="<?= $agama; ?>"><?= $agama; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Nama Lengkap</label>
                                    <select name="kelas" id="" class="form-control">
                                        <option selected disabled>Pilih Kelas</option>
                                        <?php $all_kelas = array('X', 'XI', 'XII'); ?>
                                        <?php foreach ($all_kelas as $kelas) : ?>
                                            <option value="<?= $kelas; ?>"><?= $kelas; ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Telepon</label>
                                    <input type="number" class="form-control" name="telepon" placeholder="Masukkan nomor telepon anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Nama Ibu</label>
                                    <input type="text" class="form-control" name="nama_ibu" placeholder="Masukkan Ibu anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Nama Bapak</label>
                                    <input type="text" class="form-control" name="nama_bapak" placeholder="Masukkan Bapak anda" required>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Telepon Orangtua</label>
                                    <input type="number" class="form-control" name="telepon_ortu" placeholder="Masukkan nomor telepon orangtua anda" required>
                                </div>
                        </div>
                        <div class="card-footer">
                            <div class="from-group">
                                <button class="btn btn-primary">Simpan</button>
                                <a href="peserta.php" class="btn btn-default">Kembali</a>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>