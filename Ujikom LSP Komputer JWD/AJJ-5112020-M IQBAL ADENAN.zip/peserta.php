<?php
include 'koneksi.php';
$peserta = $koneksi->query("SELECT pendaftaran.* FROM pendaftaran");
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Pendaftaran Siswa Baru</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <h1>Daftar Siswa Baru</h1>
                    <div class="col-md 12">
                        <p>
                            <a href="dashboard.php" class="btn btn-primary">Dashboard</a>
                            <a href="tambah_peserta.php" class="btn btn-primary">Tambah Peserta</a>
                            <a href="cetak_xls.php" class="btn btn-primary" target="_blank"><span class="glyphicon glyphicon-print" aria-hidden="true"> Cetak</span></a>
                        </p>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama Lengkap</td>
                                    <td>Tanggal Lahir</td>
                                    <td>Agama</td>
                                    <td>Kelas</td>
                                    <td>Telepon</td>
                                    <td>Nama Ibu</td>
                                    <td>Nama Bapak</td>
                                    <td>Telepon Orangtua</td>
                                    <td>Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php foreach ($peserta as $row) : ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['nama']; ?></td>
                                        <td><?= $row['tgl_lahir']; ?></td>
                                        <td><?= $row['agama']; ?></td>
                                        <td><?= $row['kelas']; ?></td>
                                        <td><?= $row['telepon']; ?></td>
                                        <td><?= $row['nama_ibu']; ?></td>
                                        <td><?= $row['nama_bapak']; ?></td>
                                        <td><?= $row['telepon_ortu']; ?></td>
                                        <td><a href="edit_peserta.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a> <a href="hapus_peserta.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus Data ?')">Hapus</a></td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>