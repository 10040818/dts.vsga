<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Beranda</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Aplikasi Sistem Informasi Peserta Didik SMKN X Indonesia</h2>
                <div class="row">
                    <div class="col-md-8">
                        <div class="jumbotron">
                            <h2>DIGITAL TALENT 2020 | Halaman User</h2>
                            <p class="text-danger">Selamat Datang di Website SMKN X Indonesia</p>
                            <a class="btn btn-primary btn-lg" href="beranda.php" role="button">Beranda</a>
                            <a class="btn btn-primary btn-lg" href="peserta_user.php" role="button">Data Siswa</a>
                            <a class="btn btn-primary btn-lg" href="login.php" role="button">Login</a>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <img src="assets/img/dts_2020.jpeg" alt="" class="img img-responsive">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger">
                    Dibuat oleh : M. IQBAL ADENAN - DTS2020
                </div>
            </div>
        </div>
    </div>
    <!-- script untuk loading jquery.min.js -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>