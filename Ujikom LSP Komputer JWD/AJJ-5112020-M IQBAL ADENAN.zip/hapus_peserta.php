<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}

include 'koneksi.php';

$id = $_GET['id'];
$result = $koneksi->query("DELETE FROM pendaftaran WHERE pendaftaran.id = '$id'");
header('Location:peserta.php');
