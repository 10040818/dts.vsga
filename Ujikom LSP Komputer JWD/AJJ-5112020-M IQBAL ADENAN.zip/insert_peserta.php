<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}

include 'koneksi.php';
$nama_peserta = $_POST['nama_peserta'];
$tgl_lahir = $_POST['tgl_lahir'];
$alamat = $_POST['alamat'];
$agama = $_POST['agama'];
$kelas = $_POST['kelas'];
$telepon = $_POST['telepon'];
$nama_ibu = $_POST['nama_ibu'];
$nama_bapak = $_POST['nama_bapak'];
$telepon_ortu = $_POST['telepon_ortu'];

$result = $koneksi->query("INSERT INTO pendaftaran (nama, tgl_lahir, alamat, agama, kelas, telepon, nama_ibu, nama_bapak, telepon_ortu) VALUES ('$nama_peserta', '$tgl_lahir', '$alamat', '$agama', '$kelas', '$telepon', '$nama_ibu', '$nama_bapak', '$telepon_ortu')");
header('Location:peserta.php');
