<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}

include 'koneksi.php';

$id = $_POST['id'];
$nama_peserta = $_POST['nama_peserta'];
$tgl_lahir = $_POST['tgl_lahir'];
$alamat = $_POST['alamat'];
$agama = $_POST['agama'];
$kelas = $_POST['kelas'];
$telepon = $_POST['telepon'];
$nama_ibu = $_POST['nama_ibu'];
$nama_bapak = $_POST['nama_bapak'];
$telepon_ortu = $_POST['telepon_ortu'];

$result = $koneksi->query("UPDATE pendaftaran SET 
pendaftaran.nama = '$nama_peserta', 
pendaftaran.tgl_lahir = '$tgl_lahir', 
pendaftaran.alamat = '$alamat', 
pendaftaran.agama = '$agama', 
pendaftaran.kelas = '$kelas', 
pendaftaran.telepon = '$telepon', 
pendaftaran.nama_ibu = '$nama_ibu', 
pendaftaran.nama_bapak = '$nama_bapak', 
pendaftaran.telepon_ortu = '$telepon_ortu' 
WHERE pendaftaran.id = $id");

header('Location:peserta.php');
