<?php
include 'koneksi.php';
$peserta = $koneksi->query("SELECT pendaftaran.* FROM pendaftaran");
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- link untuk loading bootstrap.css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Pendaftaran Siswa Baru</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <h1>Daftar Siswa Baru</h1>
                    <div class="col-md 12">
                        <p>
                            <a href="beranda.php" class="btn btn-primary">Beranda</a>
                        </p>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama Lengkap</td>
                                    <td>Tanggal Lahir</td>
                                    <td>Agama</td>
                                    <td>Kelas</td>
                                    <td>Telepon</td>
                                    <td>Nama Ibu</td>
                                    <td>Nama Bapak</td>
                                    <td>Telepon Orangtua</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php foreach ($peserta as $row) : ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['nama']; ?></td>
                                        <td><?= $row['tgl_lahir']; ?></td>
                                        <td><?= $row['agama']; ?></td>
                                        <td><?= $row['kelas']; ?></td>
                                        <td><?= $row['telepon']; ?></td>
                                        <td><?= $row['nama_ibu']; ?></td>
                                        <td><?= $row['nama_bapak']; ?></td>
                                        <td><?= $row['telepon_ortu']; ?></td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- script untuk loading jquery.min.js  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>