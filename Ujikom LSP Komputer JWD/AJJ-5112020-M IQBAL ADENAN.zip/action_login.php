<?php
include 'koneksi.php';
$username = $_POST['username'];
$password = md5($_POST['password']);



$cek = $koneksi->query("SELECT * FROM pengguna WHERE pengguna.username = '$username'");
$result = mysqli_fetch_assoc($cek);

if ($username == $result['username'] && $password == $result['password']) {
    session_start();
    $_SESSION['username'] = $username;
    header('Location:dashboard.php');
} else {
    header('Location:beranda.php');
}
