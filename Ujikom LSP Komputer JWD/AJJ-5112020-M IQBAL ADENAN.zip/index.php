<?php
header('Location:beranda.php');
